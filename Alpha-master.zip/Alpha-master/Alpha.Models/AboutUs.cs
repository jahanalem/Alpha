﻿namespace Alpha.Models
{
    public class AboutUs : Entity
    {
        public string Description { get; set; }
        public bool IsActive { get; set; }
    }
}
