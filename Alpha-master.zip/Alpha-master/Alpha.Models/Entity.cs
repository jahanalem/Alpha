﻿namespace Alpha.Models
{
    public class Entity : BaseEntity<int>
    {
        
    }
}
