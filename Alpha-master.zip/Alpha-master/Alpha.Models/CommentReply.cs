﻿namespace Alpha.Models
{
    //public class CommentReply : Entity
    //{
    //    public virtual int? CommentId { get; set; }
    //    public virtual int? UserId { get; set; }

    //    /// <summary>
    //    /// Description: توضیحات
    //    /// </summary>
    //    [StringLength(512)]
    //    public virtual string Description { get; set; }

    //    /// <summary>
    //    /// Comment: 
    //    /// </summary>
    //    public virtual Comment Comment { get; set; }

    //    /// <summary>
    //    /// UserMemberShip:
    //    /// </summary>
    //    public virtual User User { get; set; }
    //}
}
