﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Alpha.Models;
using Alpha.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace Alpha.Services.Extensions
{
    public static class ServiceExtensions
    {
        
    }
}
