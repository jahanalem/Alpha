﻿using Alpha.Models;

namespace Alpha.Services.Interfaces
{
    public interface IAboutUsService : IBaseService<AboutUs>
    {

    }
}