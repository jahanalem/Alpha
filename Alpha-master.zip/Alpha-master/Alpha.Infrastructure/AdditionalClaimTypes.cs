﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Alpha.Infrastructure
{
    public static class AdditionalClaimTypes
    {
        public static string Picture = "picture";
        public static string Locale = "locale";
    }
}
