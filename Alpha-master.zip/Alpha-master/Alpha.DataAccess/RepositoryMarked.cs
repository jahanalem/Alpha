﻿using System;
using System.Collections.Generic;
using System.Text;
using Alpha.DataAccess.Interfaces;

namespace Alpha.DataAccess
{
    public class RepositoryMarked : IRepositoryMarked
    {
    }
}
