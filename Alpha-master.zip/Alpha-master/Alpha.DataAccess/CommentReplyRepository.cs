﻿namespace Alpha.DataAccess
{
    public class CommentReplyRepository //: Repository<CommentReply>, ICommentReplyRepository
    {
        //public CommentReplyRepository(ApplicationDbContext context) : base(context)
        //{
        //}
    }
}
