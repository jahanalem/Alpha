﻿using Alpha.Models;

namespace Alpha.DataAccess.Interfaces
{
    public interface IContactUsRepository : IRepository<ContactUs>
    {
    }
}
