﻿using Alpha.Models;

namespace Alpha.DataAccess.Interfaces
{
    public interface ITagRepository : IRepository<Tag>
    {
    }
}