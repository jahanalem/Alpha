﻿namespace Alpha.DataAccess.Interfaces
{
    //public interface ICommentReplyRepository : IRepository<CommentReply>
    //{
    //}
}
