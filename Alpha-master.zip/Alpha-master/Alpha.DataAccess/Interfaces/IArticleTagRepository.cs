﻿using Alpha.Models;

namespace Alpha.DataAccess.Interfaces
{
    public interface IArticleTagRepository : IRepository<ArticleTag>
    {
    }
}
