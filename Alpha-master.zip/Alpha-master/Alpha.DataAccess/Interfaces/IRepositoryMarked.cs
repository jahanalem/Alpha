﻿namespace Alpha.DataAccess.Interfaces
{
    public interface IRepositoryMarked
    {
        
    }
}