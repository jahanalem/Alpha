﻿using Alpha.Models;

namespace Alpha.DataAccess.Interfaces
{
    public interface IAttachmentFileRepository : IRepository<AttachmentFile>
    {
    }
}
