﻿using Alpha.Models;

namespace Alpha.DataAccess.Interfaces
{
    public interface ICommentRepository : IRepository<Comment>
    {
    }
}
