﻿namespace Alpha.ViewModels
{
    public class EditCommentViewModel
    {
        public int CommentId { get; set; }
        public int ArticleId { get; set; }
        public string Dsc { get; set; }
    }
}
