﻿namespace Alpha.ViewModels
{
    public class SendCommentViewModel
    {
        public string Dsc { get; set; }
        public int ArticleId { get; set; }
        public int? ParentId { get; set; }
    }
}
