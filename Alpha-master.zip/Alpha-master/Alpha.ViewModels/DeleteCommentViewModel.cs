﻿namespace Alpha.ViewModels
{
    public class DeleteCommentViewModel
    {
        public int CommentId { get; set; }
        public int ArticleId { get; set; }
    }
}
