﻿namespace Alpha.ViewModels
{
    public class BaseViewModel
    {   
        public virtual int ViewModelId { get; set; }
    }
}
