﻿namespace Alpha.Web.App.Areas.Admin
{
    public static class AreaConstants
    {
        public const string AdminArea = "Admin";
    }
}
