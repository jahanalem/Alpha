﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Alpha.DataAccess;
using Alpha.Models.Identity;
using Alpha.Services;
using Alpha.Web.App.Controllers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Linq.Dynamic.Core;
using Alpha.Infrastructure;
using Alpha.Infrastructure.PaginationUtility;
using Alpha.ViewModels;
using Alpha.Web.App.Resources.Constants;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Alpha.Web.App.Resources.AppSettingsFileModel;

namespace Alpha.Web.App.Areas.Admin.Controllers
{
    [Authorize(Policy = PolicyTypes.SuperAdmin)]
    [Area(AreaConstants.AdminArea)]
    public class UsersController : BaseController
    {
        private UserManager<User> _userManager;
        private IUserValidator<User> _userValidator;
        private IPasswordValidator<User> _passwordValidator;
        private IPasswordHasher<User> _passwordHasher;
        //private RoleManager<Role> _roleManager;
        //private IUserRoleStore<UserRole> _userRoleStore;

        private IUserService _userService;
        private IOptions<AppSettingsModel> _appSettings;
        public UsersController(UserManager<User> usrMgr,
                                IUserValidator<User> userValid,
                                IPasswordValidator<User> passValid,
                                IPasswordHasher<User> passwordHash,
                                IOptions<AppSettingsModel> appSettings)
        {
            _userManager = usrMgr;
            _userValidator = userValid;
            _passwordValidator = passValid;
            _passwordHasher = passwordHash;
            _appSettings = appSettings;
            //_roleManager = roleMgr;
            _userService = new UserService(this.ModelState, _userManager, _userValidator, _passwordValidator, _passwordHasher);
        }
        public async Task<IActionResult> Index(int pageNumber = 1)
        {
            UsersViewModel result = new UsersViewModel();
            string key = "totalUsers";
            var usersQuery = _userManager.Users;

            if (TempData[key] == null)
            {
                TempData[key] = await usersQuery.CountAsync();
            }
            var itemsPerPage = _appSettings.Value.DefaultItemsPerPage;// PagingInfo.DefaultItemsPerPage;
            result.Users = await usersQuery.OrderByDescending(c => c.Id)
                .Skip((pageNumber - 1) * itemsPerPage)
                .Take(itemsPerPage)
                .ToListAsync();
            var totalUsers = int.Parse(TempData[key].ToString());
            result.Pagination.Init(new Pagination
            {
                PagingInfo = new PagingInfo
                {
                    TotalItems = totalUsers,
                    ItemsPerPage = itemsPerPage,
                    CurrentPage = pageNumber
                },
                Url = Url.Action(action: "Index", controller: "Users", new { area = "Admin", pageNumber = pageNumber })
            });

            return View(result);
        }

        #region Edit

        [HttpGet]
        public IActionResult Edit(string id)
        {
            //List<string> propertyNames = DynamicOperation.GetNamesOfProperties(typeof(UserEditViewModel));
            //ViewData["PropertyList"] = propertyNames;
            if (string.IsNullOrEmpty(id))
            {
                return RedirectToAction("Index", "Users");
            }
            User user = _userManager.Users.FirstOrDefault(u => u.Id == int.Parse(id));
            return View(user);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(User userObj)
        {
            if (ModelState.IsValid)
            {
                IdentityResult consequence = await _userService.EditUser(userObj);
                if (consequence.Succeeded)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    AddErrorsFromResult(consequence);
                }
            }
            return View();
        }

        #endregion

        #region Delete

        [HttpPost]
        public IActionResult Delete(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return Json(data: true);//RedirectToAction("Index", "Users");
            }
            var result = _userService.DeleteAsync(id);

            if (result.Result.Succeeded)
            {
                return RedirectToAction("Index");
            }
            return Json(data: false);
        }

        #endregion

        //public IActionResult LoadData()
        //{

        //    var draw = HttpContext.Request.Form["draw"].FirstOrDefault();
        //    // Skiping number of Rows count
        //    var start = Request.Form["start"].FirstOrDefault();
        //    // Paging Length 10,20
        //    var length = Request.Form["length"].FirstOrDefault();
        //    // Sort Column Name
        //    var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
        //    // Sort Column Direction ( asc ,desc)
        //    var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
        //    // Search Value from (Search box)
        //    var searchValue = Request.Form["search[value]"].FirstOrDefault();

        //    //Paging Size (10,20,50,100)
        //    int pageSize = length != null ? Convert.ToInt32(length) : 0;
        //    int skip = start != null ? Convert.ToInt32(start) : 0;
        //    int recordsTotal = 0;
        //    IQueryable<User> data = _userManager.Users;

        //    //using (_context)
        //    {
        //        // Getting all Customer data
        //        IQueryable<User> userData = data; //_context.CustomerTB.Select(tempcustomer => tempcustomer);

        //        //Sorting
        //        if (!(string.IsNullOrEmpty(sortColumn) && string.IsNullOrEmpty(sortColumnDirection)))
        //        {
        //            if (sortColumn == string.Empty) sortColumn = "Id";
        //            var order = $"{sortColumn} {sortColumnDirection}";
        //            userData = data.OrderBy(order);
        //        }
        //        //Search
        //        if (!string.IsNullOrEmpty(searchValue))
        //        {
        //            userData = data.AsQueryable().Where(m => m.Email.ToLower().Contains(searchValue) || m.UserName.ToLower().Contains(searchValue));
        //        }
        //        data = userData.Skip(skip).Take(pageSize);
        //        //total number of rows count 
        //        recordsTotal = userData.Count();
        //        //Paging 

        //    }
        //    var result = new List<UsersViewModel>();
        //    foreach (User u in data.ToList())
        //    {
        //        List<string> rolesOfUser = _applicationDbContext.UserRoles.Where(c => c.User.Id == u.Id).Select(c => c.Role.Name).ToList();

        //        var vm = new UsersViewModel { Id = u.Id, UserName = u.UserName, Email = u.Email, RoleNames = rolesOfUser };
        //        result.Add(vm);
        //    }

        //    //Returning Json Data
        //    JsonResult jsonResult = Json(new { draw = draw, recordsFiltered = recordsTotal, recordsTotal = recordsTotal, data = result });
        //    return jsonResult;
        //}
    }
}