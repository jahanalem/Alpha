﻿namespace Alpha.Web.App.Resources.Constants
{
    public static class PolicyTypes
    {
        public const string OrdinaryUsers = "Users";
        public const string SuperAdmin = "Admins";
    }
}
