﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Alpha.Web.App.Resources.Constants
{
    public static class ConstantValues
    {
        public const int DefaultItemsPerPage = 3;
    }
}
