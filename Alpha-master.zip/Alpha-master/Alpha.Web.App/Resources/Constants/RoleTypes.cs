﻿namespace Alpha.Web.App.Resources.Constants
{
    public static class RoleTypes
    {
        public const string Users = "Users";
        public const string Admins = "Admins";
    }
}
